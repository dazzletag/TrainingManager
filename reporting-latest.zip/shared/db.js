const sql = require("mssql");

let poolPromise = null;

function getConnectionString() {
  const direct = process.env.REPORTING_DB_CONNECTION_STRING;
  if (direct && !direct.includes("@Microsoft.KeyVault")) {
    return direct;
  }
  const host = process.env.DB_HOST;
  const name = process.env.DB_NAME;
  const user = process.env.DB_USERNAME;
  const password = process.env.DB_PASSWORD;
  if (!host || !name || !user || !password) {
    throw new Error("Database connection settings are not configured");
  }
  return `Server=tcp:${host},1433;Database=${name};User ID=${user};Password=${password};Encrypt=true;TrustServerCertificate=false;Connection Timeout=30;`;
}

async function getPool() {
  if (!poolPromise) {
    poolPromise = sql.connect(getConnectionString());
  }
  return poolPromise;
}

async function query(text, params = {}) {
  const pool = await getPool();
  const request = pool.request();
  Object.entries(params).forEach(([key, value]) => {
    request.input(key, value);
  });
  const result = await request.query(text);
  return result.recordset ?? [];
}

module.exports = {
  query,
};
